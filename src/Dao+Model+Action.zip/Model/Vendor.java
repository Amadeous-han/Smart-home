package Model;

public class Vendor {
	 private String Id;
	 private String VName;
	 private String VCode;
	 public String getID() {return Id;}
	 public void setID(String id) {Id=id;}
	    
	 public String getVName() {return VName;}
	 public void setVname(String name) {VName=name;}
	    
	 public String getVCode() {return VCode;}
	 public void setVCode(String code) {VCode=code;}

}
