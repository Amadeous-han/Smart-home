package Model;

public class Administration {
    private String Id;
    private String AName;
    private String ACode;
	public String getID() {return Id;}
	public void setID(String id) {Id=id;}
	    
	public String getAName() {return AName;}
	public void setAname(String name) {AName=name;}
	    
	public String getACode() {return ACode;}
	public void setACode(String code) {ACode=code;}

}
